#!/bin/sh
git subtree pull -P client git://github.com/dodo/ulatency.git HEAD
git subtree pull -P docs/wiki git://github.com/poelzi/ulatencyd.wiki.git HEAD

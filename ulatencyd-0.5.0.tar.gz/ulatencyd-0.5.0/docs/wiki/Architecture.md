# Architecture

[[/docs/architecture.png]]

## FIXME
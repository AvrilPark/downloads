There are a lot of knobs we can turn:

* irq masking.
  http://www.kernel.org/doc/Documentation/filesystems/proc.txt
  there is a way to remove irq from processors. most system got more then one, so what would happen if the current active program is always run
  on a irq free processor ?

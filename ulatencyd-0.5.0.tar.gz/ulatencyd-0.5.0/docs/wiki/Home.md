Welcome to the ulatencyd wiki!

* [How does it work](wiki/How-does-it-work)
* [FAQ (before you ask)](wiki/Faq)
* [Mailinglist](http://groups.google.com/group/ulatencyd)

# Package Repositories
* [Ubuntu](https://launchpad.net/~ulatencyd/+archive/stable) **NEW LOCATION !!!**
* [Arch](http://aur.archlinux.org/packages.php?O=0&K=ulatencyd&do_Search=Go)


# For Admins
* [Adjusting the default scheduler](wiki/Adjusting-default-scheduler)
* [Flags](wiki/Flags)

# Developers Corner
* [Start Hacking](wiki/Start-Hacking)
* [Writing Rules](wiki/Writing-Rules)
* Writing Modules
* [Ideas to test](wiki/Ideas-to-test)

# Specifications
* [Generic DBUS interface](wiki/specs/dbus)
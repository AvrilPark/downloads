/* This file was automatically generated.  Do not edit! */
LUALIB_API int luaopen_bc(lua_State *L);
bc_num Bget(lua_State *L,int i);
void Bnew(lua_State *L,bc_num x);
void bc_error(const char *mesg);

WARNING: this program is under development and only suited for testing.

# ulatencyd client

it's meant to be a usable client (cli and gui) for the [ulatencyd](https://github.com/poelzi/ulatencyd) deamon.

## Dependency

* python-dbus
* python 2.5>
* ulatencyd
* python-qt4 (optional)